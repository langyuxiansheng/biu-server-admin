'use strict';

module.exports = require('require-directory')(module);